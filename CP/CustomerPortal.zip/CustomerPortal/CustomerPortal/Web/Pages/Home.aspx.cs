﻿using System;

namespace Site.Pages
{
	public partial class Home : System.Web.UI.Page
	{
		protected void Page_Load(object sender, EventArgs e) {}
	}
}
