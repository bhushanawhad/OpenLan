﻿namespace Site.Pages
{
	public partial class Page : System.Web.UI.Page {}
}
