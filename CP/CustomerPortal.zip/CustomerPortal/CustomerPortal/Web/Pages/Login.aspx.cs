﻿using System;

namespace Site.Pages
{
	public partial class Login : PortalPage
	{
		protected void Page_Load(object sender, EventArgs e)
		{
		}
	}
}
