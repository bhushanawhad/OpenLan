﻿using System;

namespace Site.Pages
{
	public partial class SiteMap : System.Web.UI.Page
	{
		protected void Page_Load(object sender, EventArgs e) {}
	}
}
