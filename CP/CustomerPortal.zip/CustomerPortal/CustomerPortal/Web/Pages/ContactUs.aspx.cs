﻿using System;
using System.Web.UI.WebControls;
using Microsoft.Xrm.Portal.Web.UI.WebControls;
using Site.Library;

namespace Site.Pages
{
	public partial class ContactUs : System.Web.UI.Page
	{
		protected void Page_Load(object sender, EventArgs e)
		{
		}
	}
}
